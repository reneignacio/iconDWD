#' Convertir archivos .grib2 a .nc
#'
#' Esta función convierte archivos de formato .grib2 a formato .nc (NetCDF) utilizando
#' una llamada al sistema para ejecutar un script de bash en WSL. La función puede
#' operar en modo secuencial o paralelo.
#'
#' @param ruta_in Vector de caracteres con las rutas de los archivos de entrada .grib2.
#' @param ruta_script Ruta del script dentro de wsl("/home/...")
#' @param parallel Lógico, indica si la conversión debe realizarse en paralelo. Por defecto es `FALSE`.
#' @param ncores Entero, número de núcleos a utilizar para la conversión en paralelo. Solo aplica si `parallel` es `TRUE`. Por defecto, usa todos los núcleos disponibles menos uno.
#' @param verbose Lógico, indica si la función debe imprimir mensajes sobre el progreso de la conversión. Por defecto es `TRUE`.
#'
#' @details
#' Para el funcionamiento en modo paralelo, esta función depende del paquete `doSNOW` y
#' configura un clúster SOCK para la ejecución paralela de las conversiones. La conversión
#' de rutas de Windows a WSL se realiza mediante la función `convertirRutaWindowsAWSL`,
#' que debe estar definida previamente o ser parte del mismo paquete.
#'
#' La barra de progreso y el cálculo del tiempo estimado se añaden para mejorar la
#' interacción del usuario con la función, especialmente útil para conversiones de
#' larga duración.
#'
#' @return
#' La función no retorna un objeto. Los archivos .nc son escritos en las rutas especificadas
#' por `ruta_out`.
#'
#' @examples
#' \dontrun{
#' ruta_in <- c("/path/to/input/file1.grib2", "/path/to/input/file2.grib2")
#' ruta_script_wsl <- "/home/inia/ICON_0125/transform_0125.sh"
#' Grib2ANetCDF(ruta_in, ruta_out, ruta_script, parallel = TRUE, verbose = TRUE)
#' }
#'
#' @export
#' @importFrom glue glue
#' @import doSNOW
#' @import pbapply
#' @import R.utilsGrib2ANetCDF <- function(ruta_in, ruta_script, parallel = FALSE, ncores = detectCores() - 3, verbose = TRUE) {
Grib2ANetCDF <- function(ruta_in, ruta_script, parallel = FALSE, ncores = detectCores() - 3, verbose = TRUE) {

  generarRutaSalida <- function(ruta) {
    ruta_salida <- sub("\\.grib2$", ".nc", ruta)
    return(ruta_salida)
  }

  modificarRutaSalida <- function(ruta) {
    separador <- .Platform$file.sep
    partes <- unlist(strsplit(ruta, separador, fixed = TRUE))
    longitud <- length(partes)
    ruta_dir_padre <- do.call(file.path, as.list(partes[1:(longitud - 1)]))
    ruta_dir_padre_netCDF <- file.path(ruta_dir_padre, "NetCDF")
    if (!dir.exists(ruta_dir_padre_netCDF)) {
      dir.create(ruta_dir_padre_netCDF, recursive = TRUE, showWarnings = TRUE)
    }
    ruta_modificada <- file.path(ruta_dir_padre_netCDF, partes[longitud])
    return(ruta_modificada)
  }

  # Verificar si hay archivos en ruta_in
  if (length(ruta_in) == 0) {
    stop("No hay archivos .grib2 para procesar.")
  }

  ruta_out <<- sapply(ruta_in, generarRutaSalida, USE.NAMES = FALSE)
  ruta_out_modificada <<- sapply(ruta_out, modificarRutaSalida, USE.NAMES = FALSE)

  # Debug print
  print("Rutas de salida generadas:")
  print(ruta_out)
  print("Rutas de salida modificadas:")
  print(ruta_out_modificada)

  archivos_existentes <- file.exists(ruta_out_modificada)

  # Debug print
  print("Archivos existentes:")
  print(archivos_existentes)

  ruta_in <<- ruta_in[!archivos_existentes]
  ruta_out_modificada <<- ruta_out_modificada[!archivos_existentes]

  # Debug print
  print("Rutas de entrada después de filtrar archivos existentes:")
  print(ruta_in)
  print("Rutas de salida modificadas después de filtrar archivos existentes:")
  print(ruta_out_modificada)

  if (length(ruta_in) == 0) {
    if (verbose) cat("No hay archivos nuevos para procesar.\n")
    return()
  }

  tiempo_inicio <- Sys.time()
  ruta_base_script <<- dirname(ruta_script)
  ruta_script <<- ruta_script

  if (!parallel) {
    if (verbose) cat(glue("Iniciando la conversión de {length(ruta_in)} archivo(s) de .grib2 a .nc...\n"))

    for (i in seq_along(ruta_in)) {
      if (verbose) cat(glue("Procesando {ruta_in[i]}...\n"))

      rutaWSL_in <- convertirRutaWindowsAWSL(ruta_in[i])
      rutaWSL_out <- convertirRutaWindowsAWSL(ruta_out_modificada[i])
      comando <- glue("wsl bash -c ' {ruta_script} {rutaWSL_in} {rutaWSL_out} {ruta_base_script} '")
      system(comando)

      if (verbose) cat(glue("Progreso: {i}/{length(ruta_in)}\n"))
    }
    if (verbose) cat("Conversión completada.\n")
  } else {
    if (verbose) cat(glue("Iniciando la conversión paralela de {length(ruta_in)} archivo(s) de .grib2 a .nc utilizando {ncores} núcleos...\n"))
    cl <- makeCluster(ncores, type = "SOCK")
    registerDoSNOW(cl)

    # Exportar todas las variables necesarias para los nodos
    clusterExport(cl, varlist = c("convertirRutaWindowsAWSL", "glue", "ruta_base_script", "ruta_out_modificada", "ruta_script", "ruta_in", "verbose"))

    clusterEvalQ(cl, {
      library(glue)
      library(R.utils)
      library(pbapply)
      library(doSNOW)
    })

    resultados <- pbapply::pblapply(1:length(ruta_in), function(i) {
      rutaWSL_in_i <- convertirRutaWindowsAWSL(ruta_in[i])
      rutaWSL_out_i <- convertirRutaWindowsAWSL(ruta_out_modificada[i])
      comando_i <- glue("wsl bash -c ' {ruta_script} {rutaWSL_in_i} {rutaWSL_out_i} {ruta_base_script} '")
      system(comando_i)
      if (verbose) glue("Archivo {ruta_in[i]} procesado.\n") else NULL
    }, cl = cl)

    stopCluster(cl)
    if (verbose) cat("Conversión paralela completada.\n")
  }

  tiempo_fin <- Sys.time()
  tiempo_total <- tiempo_fin - tiempo_inicio
  if (verbose) cat(glue("Tiempo total de ejecución: {round(tiempo_total, 2)} segundos\n"))
}
